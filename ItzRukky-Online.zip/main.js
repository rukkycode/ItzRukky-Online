import './style.css'
function run() {
alert("Load Server?")
}
run()
if (run) {
  alert("Vite Server Loaded...")
}

document.querySelector('#app').innerHTML = `
  <h1>Itz_Rukky Online</h1>
  <a href="https://vitejs.dev/guide/features.html" target="_blank">Source Documentation</a>
<h4>Welcome to my website, click documentation for website scouce platform, anyway</h4>
`